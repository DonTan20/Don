class Vehicle:
    pass
