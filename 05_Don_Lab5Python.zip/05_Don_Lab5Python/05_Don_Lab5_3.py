class Vehicle:
    engine_capacity = "1,6 Turbo"